<link href="([\w\/\-\.]+)"
<link href="{% static '$1' %}"

<script src="([\w\/\-\.]+)"
<script src="{% static '$1' %}"